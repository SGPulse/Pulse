package com.signalgate.multipoint.di

import android.app.Application
import android.content.Context
import androidx.room.Room
import com.signalgate.multipoint.database.SignalGateDatabase
import com.signalgate.multipoint.database.repositories.BlocklistRepository
import com.signalgate.multipoint.database.repositories.CallLogRepository
import com.signalgate.multipoint.database.repositories.DataSourceRepository
import com.signalgate.multipoint.database.repositories.PendingCardRepository
import com.signalgate.multipoint.database.repositories.SettingRepository
import com.signalgate.multipoint.database.repositories.SyncHistoryRepository
import com.signalgate.multipoint.logic.CallRiskEvaluator
import com.signalgate.multipoint.logic.CallScreeningEngine
import com.signalgate.multipoint.logic.DataSyncEngine
import com.signalgate.multipoint.logic.ReliableSourceManager
import com.signalgate.multipoint.data.security.BloomFilterEngine
import org.junit.After
import org.junit.Before
import org.junit.Test
import org.koin.android.ext.koin.androidContext
import org.koin.core.context.startKoin
import org.koin.core.context.stopKoin
import org.koin.dsl.module
import org.koin.test.KoinTest
import org.koin.test.check.checkModules
import org.mockito.Mockito.mock

/**
 * KoinModuleTest — verifies the full Koin DI graph resolves without error.
 *
 * What this catches (per the runtime failure analysis):
 * - NoBeanDefFoundException: a ViewModel's constructor param has no registered binding
 * - Type mismatch: a single{} returns the wrong type for an inject<T>()
 * - Missing module: a module listed in appModule references a class from another
 *   module that hasn't been loaded yet
 *
 * What this does NOT catch:
 * - Runtime failures inside the constructor (e.g. BlocklistRepository's DB seed
 *   failing) — those are integration test territory
 * - Behavior correctness — that's unit test territory
 *
 * Implementation note: Room and SQLCipher require a real Android environment to
 * open a database. This test runs in the unit test JVM (not instrumented), so
 * we replace databaseModule with an in-memory Room database backed by mocked DAOs.
 * The Koin graph is otherwise identical to production — same module list, same
 * dependency wiring, just with a test-safe database binding.
 *
 * Run with: ./gradlew testPulseDebugUnitTest
 */
class KoinModuleTest : KoinTest {

    private lateinit var testDatabase: SignalGateDatabase

    @Before
    fun setUp() {
        val context = mock(Context::class.java)
        val application = mock(Application::class.java)

        // In-memory Room database — no SQLCipher, no file system, no device needed
        testDatabase = Room.inMemoryDatabaseBuilder(
            mock(Context::class.java),
            SignalGateDatabase::class.java
        )
            .allowMainThreadQueries()
            .build()

        // Test module replaces databaseModule with in-memory bindings
        val testDatabaseModule = module {
            single<SignalGateDatabase> { testDatabase }
            single { testDatabase.sourceDao() }
            single { testDatabase.unifiedEntryDao() }
            single { testDatabase.callLogDao() }
            single { testDatabase.settingDao() }
            single { testDatabase.syncHistoryDao() }
            single { testDatabase.pendingCardDao() }
            single { PendingCardRepository(get()) }
        }

        startKoin {
            androidContext(application)
            modules(
                testDatabaseModule,  // replaces databaseModule
                repositoryModule,
                engineModule,
                viewModelModule,
                workerModule
            )
        }
    }

    @After
    fun tearDown() {
        stopKoin()
        testDatabase.close()
    }

    /**
     * Verifies the full Koin DI graph resolves without any NoBeanDefFoundException.
     *
     * checkModules() instantiates every single{}, factory{}, and viewModel{}
     * binding in the loaded modules, following the full dependency chain.
     * If any constructor parameter has no binding, this test fails with a clear
     * error identifying exactly which class is missing a registration —
     * rather than a cryptic crash on first screen load on a device.
     */
    @Test
    fun koinGraphResolvesWithoutError() {
        checkModules()
    }

    /**
     * Verifies each repository can be resolved individually.
     * Belt-and-suspenders: checkModules() already covers this, but explicit
     * injection calls give clearer failure messages when a specific repo breaks.
     */
    @Test
    fun repositoriesResolve() {
        val dataSourceRepository = getKoin().get<DataSourceRepository>()
        val callLogRepository = getKoin().get<CallLogRepository>()
        val syncHistoryRepository = getKoin().get<SyncHistoryRepository>()
        val blocklistRepository = getKoin().get<BlocklistRepository>()
        val settingRepository = getKoin().get<SettingRepository>()
        val pendingCardRepository = getKoin().get<PendingCardRepository>()

        assert(dataSourceRepository != null) { "DataSourceRepository not resolved" }
        assert(callLogRepository != null) { "CallLogRepository not resolved" }
        assert(syncHistoryRepository != null) { "SyncHistoryRepository not resolved" }
        assert(blocklistRepository != null) { "BlocklistRepository not resolved" }
        assert(settingRepository != null) { "SettingRepository not resolved" }
        assert(pendingCardRepository != null) { "PendingCardRepository not resolved" }
    }

    /**
     * Verifies engine singletons resolve — catches the case where CallScreeningEngine
     * or CallRiskEvaluator lose their Koin registration after a module refactor.
     */
    @Test
    fun enginesResolve() {
        val callRiskEvaluator = getKoin().get<CallRiskEvaluator>()
        val callScreeningEngine = getKoin().get<CallScreeningEngine>()
        val dataSyncEngine = getKoin().get<DataSyncEngine>()
        val reliableSourceManager = getKoin().get<ReliableSourceManager>()
        val bloomFilterEngine = getKoin().get<BloomFilterEngine>()

        assert(callRiskEvaluator != null) { "CallRiskEvaluator not resolved" }
        assert(callScreeningEngine != null) { "CallScreeningEngine not resolved" }
        assert(dataSyncEngine != null) { "DataSyncEngine not resolved" }
        assert(reliableSourceManager != null) { "ReliableSourceManager not resolved" }
        assert(bloomFilterEngine != null) { "BloomFilterEngine not resolved" }
    }
}
